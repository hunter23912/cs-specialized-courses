#include "test.cpp"

int main()
{
    test();
    return 0;
}