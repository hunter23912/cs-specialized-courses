#pragma once

#include <iostream>
#include <cstring>
#include <unordered_map>
#include <vector>
using namespace std;

struct File
{
    string name;
    string content;
    int size;
    string permission; // 111��ʾ�ɶ���д��ִ�� rwx
    bool isopen;       // �ļ��Ƿ񱻴�
};

class User // �û��ļ���
{
public:
    string name;
    unordered_map<string, File> filelist;

    // �����ļ�
    void createFile(string &filename, string &filecontent, string &PERMISSION)
    {
        auto it = filelist.find(filename);
        if (it != filelist.end())
        {
            cout << "ERROR: FILE ALREADY EXISTS!" << endl;
            return;
        }
        int filesize = filecontent.size();
        filelist[filename] = File{filename, filecontent, filesize, PERMISSION, false};
        cout << "CREATE SUCCESS!" << endl;
    }

    // ���ļ�
    void openFile(string &filename)
    {
        auto it = filelist.find(filename);
        if (it == filelist.end())
        {
            cout << "[ERROR]: FILE NOT FOUND!" << endl;
            return;
        }
        it->second.isopen = true;
        cout << "OPEN SUCCESS!" << endl;
    }

    // �ر��ļ�
    void closeFile(string &filename)
    {
        auto it = filelist.find(filename);
        if (it == filelist.end())
        {
            cout << "[ERROR]: FILE NOT FOUND!" << endl;
            return;
        }
        it->second.isopen = false;
        cout << "CLOSE SUCCESS!" << endl;
    }

    // ���ļ�
    void readFile(string &filename)
    {
        auto it = filelist.find(filename);
        if (it == filelist.end())
        {
            cout << "[ERROR]: FILE NOT FOUND!" << endl;
            return;
        }
        it->second.isopen = true;
        if (it->second.permission[0] != '1')
        {
            cout << "[ERROR]: PERMISSION DENIED!" << endl;
            return;
        }
        cout << "FILE CONTENT: " << it->second.content << endl;
    }

    // д�ļ�
    void writeFile(string &filename, string &filecontent)
    {
        auto it = filelist.find(filename);
        if (it == filelist.end())
        {
            cout << "[ERROR]: FILE NOT FOUND!" << endl;
            return;
        }
        if (it->second.isopen == false)
        {
            cout << "[ERROR]: FILE NOT OPEN!" << endl;
            return;
        }
        if (it->second.permission[1] != '1')
        {
            cout << "[ERROR]: PERMISSION DENIED!" << endl;
            return;
        }
        it->second.content = filecontent;
        cout << "WRITEN SUCCESS!" << endl;
    }

    // ɾ���ļ�
    void deleteFile(string &filename)
    {
        auto it = filelist.find(filename);
        if (it == filelist.end())
        {
            cout << "[ERROR]: FILE NOT FOUND!" << endl;
            return;
        }
        if (it->second.isopen == true)
        {
            cout << "[ERROR]: FILE IS OPEN, PLEASE CLOSE IT FIRST!" << endl;
            return;
        }
        filelist.erase(it);
        cout << "DELETE SUCCESS!" << endl;
    }

    // �޸��ļ�Ȩ��
    void changePermission(string &filename, string &permission)
    {
        auto it = filelist.find(filename);
        if (it == filelist.end())
        {
            cout << "[ERROR]: FILE NOT FOUND!" << endl;
            return;
        }
        it->second.permission = permission;
        cout << "CHANGE PERMISSION SUCCESS!" << endl;
    }

    // ��ȡ�ļ��б�
    void showFileList()
    {
        if (filelist.empty())
        {
            cout << "[ERROR]: FILE LIST IS EMPTY!" << endl;
            return;
        }
        printf("%-12s%-15s%-5s\n", "FILE NAME", "PERMISSION", "SIZE");
        for (auto &file : filelist)
        {
            printf("%-12s%-15s%-5d\n", file.second.name.c_str(), file.second.permission.c_str(), file.second.size);
        }
        cout << endl;
    }
};
