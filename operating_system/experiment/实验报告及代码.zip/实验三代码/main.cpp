#include "solution.cpp"
#include <cstdio>
#include <sstream>
// ����ҳʽ�洢����

int main()
{
    while (true)
    {
        cout << "ѡ���������:" << endl;
        cout << "1. �����ַ��ҳ��" << endl;
        cout << "2. ҳ���û��㷨" << endl;
        cout << "3. �Ƚϲ�ͬ�û��㷨ȱҳ��" << endl;
        cout << "4. �˳�" << endl;
        char c;
        cin >> c;
        switch (c)
        {
        case '1':
        {
            vir_addr_to_page();
            break;
        }
        case '2':
        {
            int memory_num = 3;
            cout << "�������ڴ����:";
            cin >> memory_num;
            cout << "��ѡ��ҳ���û��㷨:" << endl;
            cout << "1. FIFO" << endl;
            cout << "2. OPT" << endl;
            cout << "3. LRU" << endl;
            cout << "4. �˳�" << endl;
            char c2;
            cin >> c2;

            cout << "������ҳ�������:" << endl;
            string s;
            getline(cin, s); // ��ȡ���з�
            getline(cin, s);
            stringstream ssin(s);
            int number;
            vector<int> list;
            // list = {4, 3, 2, 1, 4, 3, 5, 4, 3, 2, 1, 5};
            while (ssin >> number)
                list.push_back(number);

            switch (c2)
            {
            case '1':
            {
                int page_fault = FIFO(list, memory_num);
                show(list, memory_num, page_fault);
                break;
            }
            case '2':
            {
                int page_fault = OPT(list, memory_num);
                show(list, memory_num, page_fault);
                break;
            }
            case '3':
            {
                int page_fault = LRU(list, memory_num);
                show(list, memory_num, page_fault);
                break;
            }
            case '4':
                break;
            }
            break;
        }
        case '3': // �Ƚϲ�ͬ�û��㷨ȱҳ��
        {
            cout << "������ҳ�������:" << endl;
            string s;
            getline(cin, s); // ��ȡ���з�
            getline(cin, s);
            stringstream ssin(s);
            int number;
            vector<int> list;
            // list = {4, 3, 2, 1, 4, 3, 5, 4, 3, 2, 1, 5};
            while (ssin >> number)
                list.push_back(number);
            compare(list);
            break;
        }
        case '4':
            exit(0);
        }
    }
    return 0;
}