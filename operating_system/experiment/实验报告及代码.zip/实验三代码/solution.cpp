#include <iostream>
#include <vector>
#include <cstring>
#include <queue>
#include <algorithm>
using namespace std;
// ����ҳʽ�洢����

const int N = 110; // ����ַ��

const int MAX_ADDR = 1048575; // ��������ַΪ2^20-1
const int PAGE_SIZE = 1024;   // ҳ��С
int vir_addr[N];              // �����ַ����
int page[N];                  // ҳ������
char res[N][N];               // ��ʾ����
void vir_addr_to_page()
{
    srand(static_cast<int>(time(0)));
    int n = 10;
    for (int i = 1; i <= n; i++)
    {
        // ���������ַ
        int t1 = rand() % MAX_ADDR;
        vir_addr[i] = t1;
        // ��ȡҳ��
        page[i] = t1 / PAGE_SIZE;
    }
    cout << "�����ַ��:" << endl;
    for (int i = 1; i <= n; i++)
    {
        printf("vir_addr[%d] = %-10d", i, vir_addr[i]);
        cout << (i % 4 == 0 ? "\n" : "    ");
    }
    cout << endl;
    cout << "ҳ����:" << endl;
    for (int i = 1; i <= n; i++)
    {
        printf("page[%d] = %-5d", i, page[i]);
        cout << (i % 4 == 0 ? "\n" : " ");
    }
    cout << endl;
}

// show
double show(vector<int> &list, int memory_num, int page_fault)
{
    int n = list.size();
    cout << "�������:" << endl;
    for (int i = 0; i <= memory_num; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << res[i][j] << " ";
        }
        cout << endl;
    }
    cout << "ȱҳ��Ϊ:" << page_fault << endl;
    double rate = (double)page_fault / n;
    cout << "ȱҳ��Ϊ:" << rate << endl;
    return rate;
}

// FIFO�㷨
int FIFO(vector<int> &list, int memory_num)
{
    int n = list.size();
    int page_fault = 0; // ȱҳ��
    deque<int> q;
    vector<int> memory;
    int k = 0;
    memset(res, '_', sizeof(res));
    for (auto &x : list)
    {
        bool flag = false;
        bool isfull = false;
        char change;
        for (auto &y : memory)
        {
            if (y == x)
            {
                flag = true;
                res[memory_num][k] = 'T';
                k++;
                break;
            }
        }
        // ���x�����ڴ���
        if (!flag)
        {
            res[memory_num][k] = 'F';
            page_fault++;
            if (memory.size() < memory_num)
            {
                memory.push_back(x);
                q.push_back(x);
            }
            else
            {
                isfull = true;
                change = q.front();
                q.pop_front();
                q.push_back(x);
                for (auto &y : memory)
                    if (y == change)
                        y = x;
            }
            // ����res����,���flagΪtrue,�򲻸���
            for (int i = 0; i < memory.size(); i++)
                res[i][k] = memory[i] + '0';
            k++;
        }
    }
    return page_fault;
}

// OPT�㷨
int OPT(vector<int> &list, int memory_num)
{
    int n = list.size();
    int page_fault = 0; // ȱҳ��
    vector<int> memory;
    int k = 0;
    memset(res, '_', sizeof(res));
    // ������������ҳ�������
    for (int i = 0; i < n; i++)
    {
        int &x = list[i];
        bool flag = false;
        for (auto &y : memory)
        {
            if (y == x)
            {
                flag = true;
                res[memory_num][k] = 'T';
                k++;
                break;
            }
        }
        // ���x�����ڴ���
        if (!flag)
        {
            res[memory_num][k] = 'F';
            page_fault++;
            if (memory.size() < memory_num)
                memory.push_back(x);
            else
            {
                // �ҵ���������memory����Զ��ҳ��
                int s[n], top = 0;
                bool st[memory_num];
                memset(st, false, sizeof(st));
                for (int j = i + 1; j < n; j++)
                {
                    int x2 = list[j];
                    // �Ժ��������е�ÿ������ڴ��
                    for (int u = 0; u < memory.size(); u++)
                    {
                        int &y = memory[u];
                        if (y == x2)
                        {
                            if (!st[u])
                            {
                                st[u] = true;
                                s[top++] = y;
                            }
                        }
                    }
                }
                top--;

                // �ҵ��󣬸����ڴ����ָ���������
                bool done = false;
                for (int u = 0; u < memory_num; u++)
                    if (!st[u])
                    {
                        memory[u] = x;
                        done = true;
                        break;
                    }
                if (done == false)
                {
                    for (auto &y : memory)
                        if (y == s[top])
                            y = x;
                }
            }
            // ����res����
            for (int i = 0; i < memory.size(); i++)
                res[i][k] = memory[i] + '0';
            k++;
        }
    }
    return page_fault;
}

int LRU(vector<int> &list, int memory_num)
{
    int n = list.size();
    int page_fault = 0; // ȱҳ��
    vector<int> memory;
    int k = 0;
    memset(res, '_', sizeof(res));
    // ������������ҳ�������
    for (int i = 0; i < n; i++)
    {
        int &x = list[i];
        bool flag = false;
        for (auto &y : memory)
        {
            if (y == x)
            {
                flag = true;
                res[memory_num][k] = 'T';
                k++;
                break;
            }
        }
        // ���x�����ڴ���
        if (!flag)
        {
            res[memory_num][k] = 'F';
            page_fault++;
            if (memory.size() < memory_num)
                memory.push_back(x);
            else // memory�����������ң�һ�����ҵ�
            {
                // �ҵ���������memory����Զ��ҳ��
                int top;
                bool st[memory_num];
                memset(st, false, sizeof(st));
                for (int j = i - 1; j >= 0; j--)
                {
                    int x2 = list[j];
                    // �Ժ��������е�ÿ������ڴ��
                    int cnt = 0;
                    for (int u = 0; u < memory.size(); u++)
                    {
                        int &y = memory[u];
                        if (y == x2)
                        {
                            if (!st[u])
                            {
                                st[u] = true;
                                top = y;
                                cnt++;
                                if (cnt == memory_num)
                                    break;
                            }
                        }
                    }
                }
                // �ҵ��󣬸����ڴ����ָ���������
                for (auto &y : memory)
                    if (y == top)
                    {
                        y = x;
                        break;
                    }
            }
            // ����res����
            for (int i = 0; i < memory.size(); i++)
                res[i][k] = memory[i] + '0';
            k++;
        }
    }
    return page_fault;
}

void compare(vector<int> &list)
{
    for (int memory_num = 3; memory_num <= 5; memory_num++)
    {
        cout << "==================================================" << endl;
        cout << "ҳ���С: 1024B  �ڴ����: " << memory_num << endl;
        int n = list.size();
        int num_FIFO = FIFO(list, memory_num);
        double rate_FIFO = num_FIFO / (double)n;
        double hit_FIFO = 1 - rate_FIFO;
        int num_OPT = OPT(list, memory_num);
        double rate_OPT = num_OPT / (double)n;
        double hit_OPT = 1 - rate_OPT;
        int num_LRU = LRU(list, memory_num);
        double rate_LRU = num_LRU / (double)n;
        double hit_LRU = 1 - rate_LRU;
        printf("OPT    ȱҳ��: %-3d    ȱҳ��: %-4.3lf    ������: %-4.3lf\n", num_FIFO, rate_FIFO, hit_FIFO);
        printf("FIFO   ȱҳ��: %-3d    ȱҳ��: %-4.3lf    ������: %-4.3lf\n", num_OPT, rate_OPT, hit_OPT);
        printf("LRU    ȱҳ��: %-3d    ȱҳ��: %-4.3lf    ������: %-4.3lf\n", num_LRU, rate_LRU, hit_LRU);
    }
}
