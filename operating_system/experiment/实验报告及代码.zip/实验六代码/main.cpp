#include "solution.cpp"
#include <cstdio>

void show(vector<Partition> &memory)
{
    printf("%-10s%-10s%-12s%-18s\n", "������", "��С", "��ʼ��ַ", "״̬");
    for (int i = 0; i < memory.size(); i++)
    {
        string s = "����";
        if (!memory[i].free)
        {
            s = "ռ��(";
            for (auto &cur : memory[i].list)
                s += cur.x + ",";
            s.pop_back();
            s += ")";
        }
        printf("%-10d%-10d%-12d%-18s\n", i, memory[i].size, memory[i].startAddress, s.c_str());
    }
}

void choosefunc(vector<Partition> &memory, string &name, int &currentSize, int &nextIndex, char &choice, int &flag)
{
    switch (choice)
    {
    case '1':
    {
        flag = firstFit(memory, name, currentSize);
        break;
    }
    case '2':
    {
        flag = nextFit(memory, name, currentSize, nextIndex);
        break;
    }
    case '3':
    {
        flag = bestFit(memory, name, currentSize);
        break;
    }
    case '4':
    {
        flag = worstFit(memory, name, currentSize);
        break;
    }
    }
}

int main()
{
    vector<Partition> memory = {
        {40, 0},
        {100, 40},
        {350, 140},
        {150, 490}};
    int nextIndex = 0;
    while (true)
    {
        cout << "----------����ǰ�ķ����б�----------" << endl;
        show(memory);
        printf("1.�״���Ӧ�㷨\n");
        printf("2.ѭ���״���Ӧ�㷨\n");
        printf("3.�����Ӧ�㷨\n");
        printf("4.���Ӧ�㷨\n");
        printf("5.�˳�\n");
        printf("��ѡ������㷨:");
        char choice;
        cin >> choice;
        if (choice == '5')
            exit(0);
        while (true)
        {
            cout << "-------" << endl;
            cout << "|1.����|" << endl;
            cout << "|2.����|" << endl;
            cout << "|3.����|" << endl;
            cout << "-------" << endl;
            char c;
            cin >> c;
            if (c == '1')
            {
                string name = "NULL";
                int currentSize = 0;
                cout << "��������ҵ��:";
                cin >> name;
                cout << "��������ҵ��С:";
                cin >> currentSize;
                int flag = -1;
                choosefunc(memory, name, currentSize, nextIndex, choice, flag);
                if (flag == -1)
                    cout << "û���㹻�Ŀռ�" << endl;
                else
                {
                    cout << "����ɹ�,�������ʼ��ַΪ:" << flag << endl;
                    cout << "----------�ɹ������ķ����б�----------" << endl;
                    show(memory);
                }
            }
            else if (c == '2')
            {
                bool flag = false;
                cout << "������Ҫ���յ���ҵ��:";
                string name;
                cin >> name;
                flag = recycle(memory, name);
                if (flag == false)
                    cout << "����ʧ��,�޿ɻ��տռ�" << endl;
                else if (flag == true)
                {
                    cout << "���ճɹ�!" << endl;
                    cout << "---------���պ�ķ����б�---------" << endl;
                    show(memory);
                }
            }
            else if (c == '3')
                break;
        }
    }
    return 0;
}